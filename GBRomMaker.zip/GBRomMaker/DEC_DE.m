function DEC_DE()
    global PC; global rom;
    rom(PC+1) = hex2dec('1B'); PC = PC+1;
end

