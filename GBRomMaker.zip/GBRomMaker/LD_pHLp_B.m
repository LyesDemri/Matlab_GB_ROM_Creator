function LD_pHLp_B()
    global PC;global rom;
    rom(PC+1) = hex2dec('70');  PC=PC+1;
end

