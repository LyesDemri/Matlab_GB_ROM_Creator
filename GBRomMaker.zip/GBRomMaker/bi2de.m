function v = bi2de(x)

x=num2str(x); 
v=bin2dec(x);