
function LD_A_L()
    global PC;global rom;
    rom(PC+1) = hex2dec('7D'); PC=PC+1;
end

