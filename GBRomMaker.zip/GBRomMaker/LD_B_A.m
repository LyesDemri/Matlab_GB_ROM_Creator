function LD_B_A()
    global PC; global rom;
    rom(PC+1) = hex2dec('47'); PC = PC+1;
end

