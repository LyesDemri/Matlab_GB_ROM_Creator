function LD_pHLp_C()
    global PC;global rom;
    rom(PC+1) = hex2dec('71');  PC=PC+1;
end

