clear;clc;close all;

global rom;
global PC;

rom = uint8(zeros(1,2^15));

%Variable definitions:
next_audio_event_pointer_H = 'C000';
next_audio_event_pointer_L = 'C001';
next_event_timer = 'C002';

%Subroutines:
PC = hex2dec('1000');
disp(['update audio registers: ', dec2hex(PC,4)]);
update_audio_registers = dec2hex(PC,4);
PUSH_HL();
PUSH_AF();
PUSH_BC();
PUSH_DE();
%B <- number of registers to update
LD_BC(next_audio_event_pointer_H);  %HL <- next_audio_event_pointer
LD_A_pBCp();
LD_H_A();
INC_BC();
LD_A_pBCp;
LD_L_A();
LD_B_pHLp();    %B <- [HL] = [next_audio_event_pointer which is number of registers to update]
update_loop = PC;
    INC_HL();       %HL++
    LD_C_pHLp();    %C = register to be updated (starting from FF00)
    INC_HL();       %HL++
    LD_A_pHLp();    %A = new value
    LDH_pCp_A();    %register = new value
    DEC_B();        %registers left to update = registers left to update -1
JP_NZ(dec2hex(update_loop,4));
INC_HL();               %HL++
LD_D_pHLp();            %D = time to wait before next event
PUSH_HL();              %because HL holds the current audio_event_pointer 
                        %and we want to use it for a quick data transfer
LD_HL(next_event_timer); %next note timer = time to wait before next event
LD_pHLp_D();
POP_HL();
%save address of start of next audio event:
INC_HL();
LD_B_H();   %next_audio_event_pointer <- HL++
LD_C_L();
LD_HL(next_audio_event_pointer_H); 
LD_pHLp_B();
INC_HL();
LD_pHLp_C();
POP_DE();
POP_BC();
POP_AF();
POP_HL();
RET();

disp(['Handle timer interrupt: ', dec2hex(PC,4)]);
handle_timer_interrupt = dec2hex(PC,4);
PUSH_HL();
PUSH_AF();
LD_HL(next_event_timer);    %next_event_timer--
LD_A_pHLp();
DEC_A();
JR_NZ('00');startif = PC;   %if next_event_timer == 0
    CALL(update_audio_registers);   %start updating audio registers
JR('00');else1 = PC;rom(startif) = else1-startif;
    LD_pHLp_A();    %just saving the value of next_event_timer
endif = PC;rom(else1) = endif-else1;
POP_AF();
POP_HL();
RET();

%starting point of GB CPU
PC = hex2dec('0100');
JP('0150');

%define reset vector
PC = hex2dec('50');
CALL(handle_timer_interrupt);
RETI();

%Main program:
PC = hex2dec('0150');
%activate timer interrupts
LD_HL('FFFF');LD_pHLp('04');
%put right values for timer
LD_HL('FF07');LD_pHLp('04');
LD_HL('FF05');LD_pHLp('00');
%initialize music pointer
LD_HL(next_audio_event_pointer_H);LD_pHLp('30');
LD_HL(next_audio_event_pointer_L);LD_pHLp('00');
LD_HL(next_event_timer);LD_pHLp('01');
EI();
JP(dec2hex(PC,4)); %stay here. music handled by interrupts.

%music section starts here:
PC = hex2dec('3000')+1;
disp(['Music section starts at: ', dec2hex(PC,4)]);
event =  {'24','77'; %Left & right volume max
          '25','FF'; %All channels go to Left and Right
          '26','FF'; %Audio on, all channels on
          '10','00'; %no sweep
          '11','00'; %Max duration for CH1 timer
          '12','F0'; %Initial volume to the max, no envelope
          '16','00'; %Max duration for CH2 timer
          '17','F0'; %Initial volume to the max, no envelope
          
          '14','CF'; %Trigger channel, High channel 1 period 
          '13','FF'; %Low channel 1 period
          '19','CF'; %Trigger channel, High channel 2 period
          '18','B5'}; %Low channel 2 period 
insert_audio_data(event,2);

event = {'14','CF';  %Trigger channel, High channel 1 period
         '13','FF';  %Low channel 1 period 
         '19','CF';  %Trigger channel, High channel 2 period 
         '18','B5'}; %Low channel 2 period
         
insert_audio_data(event,2);

event =  {'13','FF';  %Low channel 1 period
          '14','FF';  %Trigger channel, High channel 1 period
          '18','CF';  %Low channel 2 period
          '19','B5'}; %Trigger channel, High channel 2 period 
insert_audio_data(event,2);


JP(dec2hex(PC,4));

fid = fopen('gb_music_lite_test.gb','w');
fwrite(fid,rom);
fclose(fid);

disp('Everything worked!');

function insert_audio_data(event_data,time_until_next_event)
    global PC;
    global rom;
    rom(PC) = size(event_data,1);
    PC=PC+1; %Number of registers to change
    for i = 1:size(event_data,1)
        rom(PC) = hex2dec(event_data{i,1});
        PC=PC+1;
        rom(PC) = hex2dec(event_data{i,2});
        PC=PC+1;
    end
    rom(PC) = time_until_next_event;PC=PC+1;
end