function AND_B()
    global PC; global rom;
    rom(PC+1) = hex2dec('A0'); PC = PC+1;
end

