function LD_pDEp_A()
    global PC; global rom;
    rom(PC+1) = hex2dec('12'); PC = PC+1;
end


