function LD_D_H()
    global PC;global rom;
    rom(PC+1) = hex2dec('54'); PC=PC+1;
end

