function DEC_A()
    global PC;global rom;
    rom(PC+1) = hex2dec('3D'); PC = PC+1;
end

