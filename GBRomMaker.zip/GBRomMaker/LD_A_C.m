function LD_A_C()
    global PC; global rom;
    rom(PC+1) = hex2dec('79'); PC = PC+1;
end

