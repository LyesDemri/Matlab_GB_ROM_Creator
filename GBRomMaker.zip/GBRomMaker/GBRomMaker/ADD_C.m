function ADD_C()
    global PC;global rom;
    rom(PC+1) = hex2dec('81'); PC=PC+1;
end

