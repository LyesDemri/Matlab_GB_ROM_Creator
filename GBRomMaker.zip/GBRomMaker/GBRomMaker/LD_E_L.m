function LD_E_L()
    global PC;global rom;
    rom(PC+1) = hex2dec('5D'); PC=PC+1;
end

