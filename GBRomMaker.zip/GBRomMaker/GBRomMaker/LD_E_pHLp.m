function LD_E_pHLp()
    global PC;global rom;
    rom(PC+1) = hex2dec('5E');  PC=PC+1;
end

