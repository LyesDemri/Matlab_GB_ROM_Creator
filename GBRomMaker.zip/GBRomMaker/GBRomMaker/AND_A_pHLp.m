function AND_A_pHLp()
    global PC; global rom;
    rom(PC+1) = hex2dec('A6'); PC = PC+1;
end