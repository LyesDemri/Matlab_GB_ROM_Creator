function CP_A_C()
    global PC; global rom;
    rom(PC+1) = hex2dec('B9'); PC = PC+1;
end

