function EI()
    global PC;global rom;
    rom(PC+1) = hex2dec('FB');PC=PC+1;
end

