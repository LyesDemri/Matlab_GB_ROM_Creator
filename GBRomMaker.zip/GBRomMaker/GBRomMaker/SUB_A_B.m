function SUB_A_B()
    global PC; global rom;
    rom(PC+1) = hex2dec('90'); PC = PC+1;
end

