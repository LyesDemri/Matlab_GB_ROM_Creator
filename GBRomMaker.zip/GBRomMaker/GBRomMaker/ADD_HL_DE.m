function ADD_HL_DE()
    global PC; global rom;
    rom(PC+1) = hex2dec('19');PC = PC+1;
end

