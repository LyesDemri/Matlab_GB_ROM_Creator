function DEC_E()
    global PC; global rom;
    rom(PC+1) = hex2dec('1D'); PC = PC+1;
end

