function LD_A_pDEp()
    global PC; global rom;
    rom(PC+1) = hex2dec('1A'); PC=PC+1;
end

