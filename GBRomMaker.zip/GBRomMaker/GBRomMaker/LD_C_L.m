function LD_C_L()
    global PC;global rom;
    rom(PC+1) = hex2dec('4D');  PC=PC+1;
end

