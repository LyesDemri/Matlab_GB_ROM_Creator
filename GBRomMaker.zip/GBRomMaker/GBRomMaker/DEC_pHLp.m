function DEC_pHLp()
    global PC;global rom;
    rom(PC+1) = hex2dec('35');PC = PC+1;
end

