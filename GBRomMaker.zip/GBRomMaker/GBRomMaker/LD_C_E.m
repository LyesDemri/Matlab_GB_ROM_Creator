function LD_C_E()
    global PC;global rom;
    rom(PC+1) = hex2dec('4B');  PC=PC+1;
end