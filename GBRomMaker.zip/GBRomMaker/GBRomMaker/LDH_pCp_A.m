function LDH_pCp_A()
    global PC;global rom;
    rom(PC+1) = hex2dec('E2'); PC=PC+1;
end

