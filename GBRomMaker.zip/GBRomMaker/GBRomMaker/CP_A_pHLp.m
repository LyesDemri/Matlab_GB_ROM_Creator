function CP_A_pHLp()
    global PC;global rom;
    rom(PC+1) = hex2dec('BE'); PC=PC+1;
end

