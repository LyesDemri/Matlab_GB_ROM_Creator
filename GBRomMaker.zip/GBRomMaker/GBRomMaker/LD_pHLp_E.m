function LD_pHLp_E()
    global PC;global rom;
    rom(PC+1) = hex2dec('73');  PC=PC+1;
end
