function CP_E()
    global PC; global rom;
    rom(PC+1) = hex2dec('BB'); PC=PC+1;
end

