function LD_L_A()
    global PC;global rom;
    rom(PC+1) = hex2dec('6F');  PC=PC+1;
end

