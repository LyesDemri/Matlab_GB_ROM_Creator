function CP_D()
    global PC; global rom;
    rom(PC+1) = hex2dec('BA'); PC=PC+1;
end

