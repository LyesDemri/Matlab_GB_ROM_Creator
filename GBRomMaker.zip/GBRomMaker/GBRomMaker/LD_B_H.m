function LD_B_H()
    global PC;global rom;
    rom(PC+1) = hex2dec('44');  PC=PC+1;
end

