function LD_pHLp_D()
    global PC;global rom;
    rom(PC+1) = hex2dec('72');  PC=PC+1;
end

