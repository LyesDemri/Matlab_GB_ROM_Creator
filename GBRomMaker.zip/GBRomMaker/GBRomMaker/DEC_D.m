function DEC_D()
    global PC; global rom;
    rom(PC+1) = hex2dec('15'); PC=PC+1;
end

