function LD_C_pHLp()
    global PC;global rom;
    rom(PC+1) = hex2dec('4E');  PC=PC+1;
end

