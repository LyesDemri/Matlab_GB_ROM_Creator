function LD_A_pHLp()
    global PC;global rom;
    rom(PC+1) = hex2dec('7E'); PC=PC+1;
end

