function DEC_H()
    global PC; global rom;
    rom(PC+1) = hex2dec('25');PC = PC+1;
end

