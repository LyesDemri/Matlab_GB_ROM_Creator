function CP_L()
    global PC; global rom;
    rom(PC+1) = hex2dec('BD'); PC=PC+1;
end

