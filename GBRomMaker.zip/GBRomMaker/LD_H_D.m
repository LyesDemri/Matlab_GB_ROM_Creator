function LD_H_D()
    global PC; global rom;
    rom(PC+1) = hex2dec('62'); PC = PC+1;
end

