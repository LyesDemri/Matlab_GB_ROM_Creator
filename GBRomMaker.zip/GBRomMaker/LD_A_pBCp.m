function LD_A_pBCp()
    global PC; global rom;
    rom(PC+1) = hex2dec('0A'); PC = PC+1;
end

